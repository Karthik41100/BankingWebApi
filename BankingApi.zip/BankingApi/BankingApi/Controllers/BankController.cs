﻿using BankingApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace BankingApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankController : ControllerBase
    {


       AccountBank acb = new AccountBank();

        [HttpGet]
        [Route("accountlist")]
        public IActionResult GetAllAccount()
        {
            return Ok(acb.GetAllCount());
        }

        [HttpGet]
        [Route("accountlist/searchbyAccType/{AccType}")]
        public IActionResult GetAccountbyaccountType(string AccType)
        {
            try
            {
                return Ok(acb.GetAccountByType(AccType));
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        [HttpGet]
        [Route("accountlist/searchbyAcno/{AcNo}")]

        public IActionResult GetAccountbyNo(int AcNo)
        {
            try
            {
                return Ok(acb.GetAccountByAccNo(AcNo));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        [Route("accountlist/add")]

        public IActionResult AddnewAccount([FromBody]AccountBank account,int accno)
        {
            try
            {
                string result = acb.AddNewAccount(accno,account);
                return Created("", account);
            }
            catch(Exception ex)
            {
                return Ok(ex.Message);
            }
        }
        [HttpPut]
        [Route("accountlist/edit")]

        public IActionResult EditExistingAccount([FromBody]AccountBank account)
        {
            try
            {
                string result = acb.EditAccount(account);
                return Accepted(result);
            }
            catch(Exception ex)
            {
                return Ok(ex.Message);
            }
        }
        [HttpDelete]
        [Route("accountlist/delete/{AccountNo}")]
        public IActionResult DeleteAnAccount(int AccountNo)
       
        {
            try
            {
                string result = acb.delete(AccountNo);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return Ok(ex.Message);
            }
        }
        
    }
}
