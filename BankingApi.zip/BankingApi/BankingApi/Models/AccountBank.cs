﻿using System.Security.Principal;

namespace BankingApi.Models
{
    public class AccountBank
    {
        public int AccNo { get; set; }
        public string AccName { get; set; }
        public string AccType { get; set; }
        public double AccBalance { get; set; }
        public bool IsActive { get; set; }


        public static List<AccountBank> Banks = new List<AccountBank>()
        {
            new AccountBank(){AccNo=123456,AccName="Karthik",AccType="Saving",AccBalance=20000},
            new AccountBank(){AccNo=132456,AccName="Raj",AccType="Current",AccBalance=50000 },
            new AccountBank(){AccNo=132476,AccName="Raja",AccType="Pf",AccBalance=30000 },
            new AccountBank(){AccNo=132467,AccName="Raju",AccType="Saving",AccBalance=70000 },
        };

        public List<AccountBank> GetAllCount()
        {
            return Banks;
        }
        public List<AccountBank> GetAccountByType(string AccType)
        {
            var acc = (from ac in Banks
                       where ac.AccType == AccType
                       select ac).ToList();

            return acc;
        }
        public AccountBank GetAccountByAccNo(int AcNo)
        {
            var checkac = Banks.Count(ac => ac.AccNo == AcNo);
            if (checkac == 1)
            {
                var aacnum = (from ac in Banks
                              where ac.AccNo == AcNo
                              select ac).Single();

                              return aacnum;            
    
            }
            else
            {
                throw new Exception("Acc not found");
            }
            
        }

        public string AddNewAccount(int accno,AccountBank account)
        {
            foreach(var l in Banks) 
            {
                if(l.AccNo == accno)
                {
                    throw new Exception("Account already exists");
                }
            }
            Banks.Add(account);
            return "account added successfully";
        }
        
        public string EditAccount(AccountBank account)
        {
            var count = Banks.Count(ac => ac.AccNo == account.AccNo);

            if(count > 0)
            {
             var ac =   (from acc in Banks
                 where acc.AccNo == account.AccNo
                 select acc).Single();

                ac.AccNo = account.AccNo;
                ac.AccName = account.AccName;
                ac.AccType = account.AccType;
                ac.AccBalance = account.AccBalance;

                return "Product Edited";
            }
            else
            {
                throw new Exception("Enter correct values");
            }
        }

        public string delete(int AccountNo)
        {
            var count = Banks.Count(ac => ac.AccNo == AccountNo);

            if (count > 0)
            {
                var ac = (from acc in Banks
                          where acc.AccNo == AccountNo
                          select acc).Single();
                Banks.Remove(ac);

                return "Product deleted";
            }
            else
            {
                throw new Exception("Product not deleted");
            }
        }
    }
}
